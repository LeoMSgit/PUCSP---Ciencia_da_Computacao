//DOM-LLM - Projeto Dominó – Etapa 4 - REQ17
//02/10/2024 - Grupo: LLM
//Leonardo Miguel dos Santos
//Luiz Fernando De Marchi Andrade

//Dom_LLM_Projeto.c

#include "Dom_LLM_Controller.c"

int main() {
    iniciarJogo();
    return 0;
} 	