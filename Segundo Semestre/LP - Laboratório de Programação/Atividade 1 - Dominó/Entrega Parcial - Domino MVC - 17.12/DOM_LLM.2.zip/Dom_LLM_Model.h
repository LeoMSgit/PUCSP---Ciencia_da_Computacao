//DOM-LLM - Projeto Dominó – Etapa 4 - REQ17
//02/10/2024 - Grupo: LLM
//Leonardo Miguel dos Santos
//Luiz Fernando De Marchi Andrade

// Dom_LLM_Model.h

#ifndef DOM_LLM_MODEL_H
#define DOM_LLM_MODEL_H

#define TOTAL_PECAS 28
#define MAX_JOGADORES 2
#define MIN_JOGADORES 1
#define PECAS_POR_JOGADOR 14 
#define MAX_PECAS_MESA 28 // Número máximo de peças que podem ser colocadas na mesa 


typedef struct {
    int lado1;
    int lado2;
} PecaDomino;

typedef struct {
    PecaDomino pecas[PECAS_POR_JOGADOR];   // Quais as peças do jogador
    int quantidadePecas;                   // Quantidade de peças na mado jogador
    int contadorCompras;                   // Contador de peças compradas
    int jogadasRealizadas;        		   // Contador de jogadas válidas realizadas pelo jogador
} Jogador;


typedef struct {
    PecaDomino pecas[MAX_PECAS_MESA];  	// Array para armazenar as peças jogadas na mesa
    int quantidade;  					// Contador de peças na mesa
} Mesa;

typedef struct {
    PecaDomino pecasRestantes[TOTAL_PECAS];	 // Quais peças restam no monte
    int quantidadeRestante;                  // Quantidade de peças restantes no monte
} Monte;

typedef struct {
    PecaDomino ordenadas[TOTAL_PECAS];
    PecaDomino embaralhadas[TOTAL_PECAS];
    Mesa mesa;  							// Adiciona a mesa na estrutura TipoDomino
    Monte monte;
} TipoDomino;


// Declaração externa das variáveis globais
extern TipoDomino tipo;
extern int numeroJogadores;
extern Jogador jogadores[2]; // Declaração do array de jogadores
extern Monte monte;
extern Mesa mesa;
extern int jogadorAtual;

// Funções do model
void gerarPecas(PecaDomino pecas[]);
void embaralharPecas(PecaDomino pecas[], int tamanho);
void distribuirPecas(Jogador jogadores[], PecaDomino pecasEmbaralhadas[], int numJogadores);
void inicializarMesa();
PecaDomino encontrarMaiorPeca(Jogador jogador);
int definirJogadorInicial(Jogador jogadores[], int numeroJogadores);
void exibirPecasJogadores(Jogador jogadores[], int numeroJogadores);
void inicializarMonte(PecaDomino pecas[], int quantidadeDistribuida);


#endif // DOM_LLM_MODEL_H