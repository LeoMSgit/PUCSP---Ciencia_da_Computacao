//DOM-LLM - Projeto Dominó – Etapa 4 - REQ17
//02/10/2024 - Grupo: LLM
//Leonardo Miguel dos Santos
//Luiz Fernando De Marchi Andrade

// Dom_LLM_Controller.h

#ifndef DOM_LLM_CONTROLLER_H
#define DOM_LLM_CONTROLLER_H

#include "Dom_LLM_Model.h"
#include "Dom_LLM_View.h"

// Funcoes do controller
void iniciarJogo();

#endif // DOM_LLM_CONTROLLER_H
